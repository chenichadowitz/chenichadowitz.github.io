function [posteriors] = BayesRule(feature_val, likelihoods, priors)

% If we're looking for when the pixel is OFF, take the complement of the
% likelihoods
if( feature_val ~= 255.5 )
    likelihoods = 1 - likelihoods;
end

p_pixel = dot(likelihoods, priors);

posteriors = likelihoods .* priors / p_pixel;