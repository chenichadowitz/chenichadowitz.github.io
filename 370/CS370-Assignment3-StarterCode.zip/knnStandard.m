function [accuracy] = knnStandard(train_threes, train_fives, test_threes, test_fives)
% [accuracy] = knnStandard(train_threes, train_fives, test_threes, test_fives)
% INPUT: The set of training data for threes and fives (train_threes,
%        train_fives), and the set of test data for threes and fives (test_threes,
%        test_fives).
% OUTPUT: The accuracy of this K-NN classifier after classifying every test
%         three and five.
%

    disp('Standard KNN');
    correct = 0;
    
    % Concatenate all the training images into a single 3d array    
    all_training_imgs = cat(3, train_threes, train_fives);
    
    for i=1:size(test_threes,3)+size(test_fives,3)
        disp(['[Standard KNN] classifying image #', num2str(i)]);
        
        % Extract the current test image
        if i <= size(test_threes,3) % If 1 <= i <= 50, then use test_threes
            test_im = test_threes(:, :, i);
        else % otherwise, use test_fives
            test_im = test_fives(:, :, i-size(test_threes,3));
        end

        % replicate the test_im matrix 100 times across the 3rd dimension
        % so that it has the same dimensions as all_training_imgs
        % This let's us do the same operation on each training image with
        % the test image simultaneously
        large_test_im = repmat(test_im, [1 1 100]);

        % Compute the pair-wise difference of each pixel value
        diff = large_test_im - all_training_imgs;

        % Sum across the rows of each image, then the columns of each image
        % This produces a 1x1x100 dimension array, where each value is the 
        % Euclidean distance between the test_im and each training image
        distances = sum(sum(diff.^2));

        % For simplicity, let's get rid of one extra dimension and turn it
        % into a 1x100 vector
        distances = distances(:);

        % Now let's sort them
        % Y is the sorted array, I is the sorted indices 
        [~, I] = sort(distances);

        % We're going to use K = sqrt(N) = sqrt(100) = 10
        k = 10;
        
        % Let's create a boolean vector (which have integer values 1 or 0) by 
        % seeing if the values I(1:k) are <= 50
        % Then, sum these boolean values to count the "votes" for the three class
        % Finally, compare the number of votes for threes and fives

        if sum(I(1:k) <= 50) > sum(I(1:k) > 50)
            % K-NN predicted test_im was a three
            if i <= size(test_threes,3) % If test_im was a three
                correct = correct + 1; % we got another prediction correct
            end
        else
            % K-NN predicted test_im was a five
            if i > size(test_threes,3) % correctly
                correct = correct + 1;
            end
        end
    end
    
    accuracy = correct / (size(test_threes,3) + size(test_fives,3));
