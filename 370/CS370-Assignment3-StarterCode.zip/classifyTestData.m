function [accuracy] = classifyTestData(train_threes, train_fives, test_threes, test_fives, priors, pixel)
% [accuracy] = classifyTestData(train_threes, train_fives, test_threes, test_fives, priors, pixel)
%
%   INPUT: train_threes,train_fives - the two sets of training images
%          test_threes, test_fives - the two sets of test images
%          priors - the prior probabilities for the two classes, as a 2x1 vector
%          pixel - the pixel coordinates to use as the feature, as a 2x1 vector
%   OUTPUT: accuracy - the accuracy of the provided pixel location as a
%           feature

if size(priors,1) == 1
    priors = priors';
end

classified = zeros(2,1);
likelihoods = likeFromTraining( pixel, train_threes, train_fives );

for i=1:50
    posteriors = BayesRule( test_threes(pixel(1), pixel(2), i), likelihoods, priors);
    classified(1) = classified(1) + (posteriors(1) >= posteriors(2));
    
    posteriors = BayesRule( test_fives(pixel(1), pixel(2), i), likelihoods, priors);
    classified(2) = classified(2) + (posteriors(1) < posteriors(2));
end

accuracy = sum(classified)/100;