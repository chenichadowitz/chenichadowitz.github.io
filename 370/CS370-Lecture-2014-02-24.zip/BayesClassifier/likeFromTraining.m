function [likelihoods] = likeFromTraining(pixel, train_threes, train_fives)

row = pixel(1); col = pixel(2);
likelihoods = [sum(train_threes(row, col, :) == 255.5); sum(train_fives(row, col, :) == 255.5)] / 50;