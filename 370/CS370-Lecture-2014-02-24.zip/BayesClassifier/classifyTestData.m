function [classified] = classifyTestData(train_threes, train_fives, test_threes, test_fives, priors, pixel)

priors = priors';

classified = zeros(2,1);
likelihoods = likeFromTraining( pixel, train_threes, train_fives );

for i=1:50
    posteriors = BayesRule( test_threes(pixel(1), pixel(2), i), likelihoods, priors);
    classified(1) = classified(1) + (posteriors(1) >= posteriors(2));
    
    posteriors = BayesRule( test_fives(pixel(1), pixel(2), i), likelihoods, priors);
    classified(2) = classified(2) + (posteriors(1) < posteriors(2));
end