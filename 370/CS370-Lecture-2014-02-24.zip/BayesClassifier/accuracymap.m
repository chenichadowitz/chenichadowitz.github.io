% accuracy map
% NOTE: this may take a few minutes to complete as it is not optimized

percentages = zeros(128, 128);

for i=1:128
    for j=1:128
        classified = classifyTestData(train_threes, train_fives, test_threes, test_fives, [0.5 0.5], [i j]);
        percentages(i, j) = sum(classified) / 100;
    end
end

colormap(gray);
imagesc(percentages);
        
