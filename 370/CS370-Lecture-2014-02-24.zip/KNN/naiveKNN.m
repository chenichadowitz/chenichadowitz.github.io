function [minThree minFive] = naiveKNN(train_threes, train_fives, test_im)
% Given a set of training data for threes and fives, return the probability
% that test_im is a three and a five
%
% Input: 
%   train_threes: 3-dimensional array of size 128x128x50 where each image
%                 is of a three and is 128x128 pixels
%   train_fives: as above, but each image is a five
%   test_im: a single 128x128 image that we would like to classify as a
%            three or a five
%
% Output:
%   minThree: the minimum distance that test_im is from any three
%                       image
%   minFive: the minimum distance that test_im is from any five
%                      image

%   First, we need to calculate the Euclidean distance between test_im and
%   each of the train_threes images
%   Let's save these distances in a vector.
    numThrees = size(train_threes, 3);
    threes_distances = zeros(1, numThrees);
    for i=1:numThrees
        a_three = train_threes(:, :, i);
        diff = test_im(:) - a_three(:);
        % Since we'll be comparing distances/metrics and don't care about
        % true distances, we don't need to take the square root
        threes_distances(i) = sum( diff.^2 );
    end
    
    % Let's store the minimum distance test_im is from any three image
    % in the variable that will be returned
    minThree = min(threes_distances);
    
    % Now let's do the same for fives
    numFives = size(train_fives, 3);
    fives_distances = zeros(1, numFives);
    for i=1:numFives
        a_five = train_fives(:, :, i);
        diff = test_im(:) - a_five(:);
        % Since we'll be comparing distances/metrics and don't care about
        % true distances, we don't need to take the square root
        fives_distances(i) = sum( diff.^2 );
    end
    
    % Let's store the minimum distance test_im is from any FIVE image
    % in the variable that will be returned
    minFive = min(fives_distances);
    
    % But, this only gives us K-NN for K=1....
    
    % Let's try to reduce the clutter
    % Concatenate all the training images into a single array
    all_training_imgs = cat(3, train_threes, train_fives);
    
    % Initialize an empty array to hold the distance metrics
    distances = zeros(1, size(all_training_imgs, 3));
    % Now go through each training image and compare it against our test_im
    for i=1:size(all_training_imgs, 3)
        a_digit = all_training_imgs(:,:,1);
        diff = test_im(:) - a_digit(:);
        distances(i) = sum( diff.^2 );
    end
    
    % Let's sort all these distances!
    % Y is the sorted array, I is the sorted indices 
    [Y I] = sort(distances);
    
    % Since the threes were all first, their indices are between 1 and 50
    % whereas the fives have indices between 51 and 100
    
    % Let's do K-NN for a range of K values
    for k = 1:2:25 % Iterate for odd values of k from 1 to 25
        if sum(I(1:k) <= 50) > sum(I(1:k) > 50)
            disp(strcat('k=', int2str(k), ': three'));
        else
            disp(strcat('k=',int2str(k), ': five'));
        end
    end
    