function [accuracy] = knn(train_threes, train_fives, test_im)
 
    % Concatenate all the training images into a single 3d array
    all_training_imgs = cat(3, train_threes, train_fives);
    
    % replicate the test_im matrix 100 times across the 3rd dimension
    % so that it has the same dimensions as all_training_imgs
    % This let's us do the same operation on each training image with
    % the test image simultaneously
    large_test_im = repmat(test_im, [1 1 100]);
    
    % Compute the pair-wise difference of each pixel value
    diff = large_test_im - all_training_imgs;
    
    % Sum across the rows of each image, then the columns of each image
    % This produces a 1x1x100 dimension array, where each value is the 
    % Euclidean distance between the test_im and each training image
    distances = sum(sum(diff.^2));
    
    % For simplicity, let's get rid of one extra dimension and turn it
    % into a 1x100 vector
    distances = distances(:);
    
    % Now let's sort them
    % Y is the sorted array, I is the sorted indices 
    [Y I] = sort(distances);
    

    % Let's do K-NN for a range of K values
    % Typically, K is sqrt(N) = sqrt(100) = 10
    % We make sure K is odd because it ensures a majority with only two classes
    for k = 1:2:25 % Iterate for odd values of k from 1 to 25
    % If the indices are <= 50, votes for 3; if indices > 50, votes for 5
    
    % Let's create a boolean vector (which have integer values 1 or 0) by 
    % seeing if the values I(1:k) are <= 50
    % Then, sum these boolean values to count the "votes" for the three class
    % Finally, compare the number of votes for threes and fives
    
        if sum(I(1:k) <= 50) > sum(I(1:k) > 50)
            disp(strcat('k=', int2str(k), ': three'));
        else
            disp(strcat('k=',int2str(k), ': five'));
        end
    end
    
    % Let's take a closer look at what is really happening
    
    % We want to compute the number of votes for the threes class divided
    % by the total number of votes so far, for k=1:100
    
    % Take the cumulative sum of the booleans created by comparing each
    % element of I to 50. This is the same as taking the cumulative sum of
    % votes
    Isum = cumsum(I <= 50);
    % Now we create an vector where each element is its index
    denom = [1:100]';
    % Compute the accuracy for each k=1:100 by doing element-wise division
    accuracy = Isum ./ denom;
